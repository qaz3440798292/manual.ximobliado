# Blessing Skin 手册

欢迎使用 Blessing Skin！

要开始安装？请阅读 [安装指南](/setup.md)。

遇到问题，请先阅读 [常见问题解答](/faq.md)，确认你遇到的问题不在此列后，再依照 [报告问题的正确姿势](/report.md) 中的要求联系开发者。
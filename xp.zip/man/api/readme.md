# Blessing Skin API 文档

目前 Blessing Skin API 处于试验性阶段（版本为 `0`），API 不稳定且随时会发生破坏性变更，敬请留意。
